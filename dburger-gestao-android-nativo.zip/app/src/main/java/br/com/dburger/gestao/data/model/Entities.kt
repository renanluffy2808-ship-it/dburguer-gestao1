package br.com.dburger.gestao.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.math.BigDecimal

@Entity(tableName = "insumos")
data class InsumoEntity(
    @PrimaryKey val id: String,
    val nome: String,
    val categoria: String,
    val unidadeCompra: String,
    val unidadeConsumo: String,
    val fatorConversao: Double,
    val rendimentoAproveitavelPercent: Double,
    val custoUnitarioConsumo: Double, // armazenado com 4 casas
    val estoqueAtual: Double,
    val estoqueMinimo: Double,
    val fornecedorNome: String? = null,
    val dataValidade: String? = null,
    val ativo: Boolean = true
)

@Entity(tableName = "compras")
data class CompraEntity(
    @PrimaryKey val id: String,
    val numeroNota: String,
    val data: String,
    val fornecedorNome: String,
    val valorTotalInformado: Double,
    val conferido: Boolean = true,
    val observacoes: String? = null,
    val criadoEm: String
)

@Entity(tableName = "itens_compra")
data class ItemCompraEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val compraId: String,
    val insumoId: String,
    val insumoNome: String,
    val quantidadeCompra: Double,
    val unidadeCompra: String,
    val precoUnitarioCompra: Double,
    val subtotal: Double
)

@Entity(tableName = "produtos")
data class ProdutoEntity(
    @PrimaryKey val id: String,
    val nome: String,
    val categoria: String,
    val descricao: String? = null,
    val precoVenda: Double,
    val custoEmbalagemManual: Double = 1.15,
    val tempoPreparoMinutos: Int = 10,
    val ativo: Boolean = true
)

@Entity(tableName = "itens_ficha_tecnica")
data class ItemFichaEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val produtoId: String,
    val insumoId: String,
    val quantidadeConsumo: Double,
    val observacao: String? = null
)

@Entity(tableName = "movimentacoes_estoque")
data class MovimentacaoEstoqueEntity(
    @PrimaryKey val id: String,
    val dataHora: String,
    val insumoId: String,
    val insumoNome: String,
    val tipo: String, // ENTRADA_COMPRA, SAIDA_VENDA, PERDA_DESCARTE, AJUSTE_MANUAL, ESTORNO_VENDA
    val quantidade: Double,
    val unidade: String,
    val custoUnitarioMomento: Double,
    val motivo: String,
    val referenciaId: String? = null
)

@Entity(tableName = "pedidos_venda")
data class PedidoVendaEntity(
    @PrimaryKey val id: String,
    val numeroPedido: Int,
    val dataHora: String,
    val status: String, // CONCLUIDO, CANCELADO
    val subtotal: Double,
    val desconto: Double,
    val valorFinal: Double,
    val formaPagamento: String, // pix, dinheiro, debito, credito
    val taxaPagamentoPercent: Double,
    val valorTaxa: Double,
    val valorLiquidoRecebido: Double,
    val cmvTotalMomento: Double,
    val reservaOperacionalMomento: Double,
    val valorReposicaoEstoqueMomento: Double,
    val lucroEstimadoMomento: Double,
    val observacoes: String? = null,
    val canceladoEm: String? = null,
    val motivoCancelamento: String? = null
)

@Entity(tableName = "lancamentos_caixa")
data class LancamentoCaixaEntity(
    @PrimaryKey val id: String,
    val dataHora: String,
    val tipo: String, // ENTRADA, SAIDA
    val categoria: String, // RECEBIMENTO_VENDA, REPOSICAO_ESTOQUE, RESERVA_OPERACIONAL, DESPESA_PAGA, TAXA_PAGAMENTO, PERDA_DESPERDICIO, RETIRADA_PRO_LABORE
    val valor: Double,
    val descricao: String,
    val pedidoId: String? = null,
    val compraId: String? = null
)

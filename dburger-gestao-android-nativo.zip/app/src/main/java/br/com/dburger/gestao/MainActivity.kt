package br.com.dburger.gestao

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import br.com.dburger.gestao.ui.theme.DBurgerTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DBurgerTheme {
                MainAppScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen() {
    var selectedTab by remember { mutableStateOf(0) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("D’ Burger Gestão", style = MaterialTheme.typography.titleLarge) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Dashboard, contentDescription = "Painel") },
                    label = { Text("Painel") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.Kitchen, contentDescription = "Insumos") },
                    label = { Text("Insumos") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.MenuBook, contentDescription = "Cardápio") },
                    label = { Text("Cardápio") }
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Default.PointOfSale, contentDescription = "PDV") },
                    label = { Text("PDV") }
                )
                NavigationBarItem(
                    selected = selectedTab == 4,
                    onClick = { selectedTab = 4 },
                    icon = { Icon(Icons.Default.AttachMoney, contentDescription = "Caixa") },
                    label = { Text("Caixa") }
                )
            }
        }
    ) { paddingValues ->
        Box(modifier = Modifier.padding(paddingValues)) {
            when (selectedTab) {
                0 -> PainelScreen()
                1 -> InsumosScreen()
                2 -> CardapioScreen()
                3 -> PdvScreen()
                4 -> CaixaScreen()
            }
        }
    }
}

@Composable fun PainelScreen() { Text("Painel com Vendas, CMV, Reserva e Saldo de Caixa") }
@Composable fun InsumosScreen() { Text("Cadastro de Insumos com Conversão Automática") }
@Composable fun CardapioScreen() { Text("Cardápio: Simples, Artesanal e Smash com Fichas Técnicas") }
@Composable fun PdvScreen() { Text("PDV Rápido com baixa automática de estoque") }
@Composable fun CaixaScreen() { Text("Fluxo de Caixa e Destinação do Dinheiro") }
